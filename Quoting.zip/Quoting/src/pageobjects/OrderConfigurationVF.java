package pageobjects;

import java.util.List;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import com.provar.core.testapi.annotations.*;

@SalesforcePage( title=""                                
               , summary=""
               , page="OrderConfigurationVF"
               , namespacePrefix=""
               , object="OrderItem"
               , connection="Admin"
     )             
public class OrderConfigurationVF {

	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!orderItemObj.Configured__c}\"]")
	@SalesforceField(name = "Configured__c", object = "OrderItem")
	public WebElement formCompleted;
	
}
